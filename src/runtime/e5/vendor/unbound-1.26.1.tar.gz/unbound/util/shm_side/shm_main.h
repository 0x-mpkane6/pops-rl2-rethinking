/*
 * util/shm_side/shm_main.h - control the shared memory for unbound.
 *
 * Copyright (c) 2007, NLnet Labs. All rights reserved.
 *
 * This software is open source.
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 
 * Redistributions of source code must retain the above copyright notice,
 * this list of conditions and the following disclaimer.
 * 
 * Redistributions in binary form must reproduce the above copyright notice,
 * this list of conditions and the following disclaimer in the documentation
 * and/or other materials provided with the distribution.
 * 
 * Neither the name of the NLNET LABS nor the names of its contributors may
 * be used to endorse or promote products derived from this software without
 * specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
 * A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
 * HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 * SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED
 * TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
 * PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
 * LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
 * NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

/**
 * \file
 *
 * This file contains functions for the SHM side.
 */

#ifndef UTIL_SHM_SIDE_MAIN_H
#define UTIL_SHM_SIDE_MAIN_H
struct daemon;
struct worker;

/* get struct ub_shm_stat_info */
#include "libunbound/unbound.h"

#include "util/locks.h"

/**
 * The SHM info.
 */
struct shm_main_info {
	/** stats_info array, shared memory segment.
	 * [0] is totals, [1..thread_num] are per-thread stats */
	struct ub_stats_info* ptr_arr;
	/** the global stats block, shared memory segment */
	struct ub_shm_stat_info* ptr_ctl;
	int key;
	int id_ctl;
	int id_arr;

	/** This mutex is on the volley information. */
	lock_basic_type lock;
	/** If there is a volley, a number of stat timer callbacks by the
	 * threads, in progress. If not, there is no volley in progress and the
	 * previous stat run has terminated succesfully for all threads.
	 * Usually activated by the first thread and deactivated by the last
	 * thread that starts its stat callback. */
	int volley_in_progress;
	/** Per thread, if they have put in stats. 0 if not. */
	int* thread_volley;
	/** The total stats of the thread stat timers, it is in progress */
	struct ub_stats_info total_in_progress;
};

int shm_main_init(struct daemon* daemon);
void shm_main_shutdown(struct daemon* daemon);
void shm_main_run(struct worker *worker);

#endif /* UTIL_SHM_SIDE_MAIN_H */
